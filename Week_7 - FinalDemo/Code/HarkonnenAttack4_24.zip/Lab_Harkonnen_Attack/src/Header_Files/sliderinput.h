/***************************************************************************//**
 * @file
 * @brief Button functionality
 ******************************************************************************/


#ifndef SLIDERINPUT_H
#define SLIDERINPUT_H

#include "em_gpio.h"
#include "capsense.h"

#define SLIDER_TASK_STACK_SIZE      960

#define SLIDER_TASK_PRIO            20

#define CAPSLIDER_DEFAULT 0x04

// CAPSENSE Channel 0 is
#define CSEN0_port gpioPortC
#define CSEN0_pin  0u
#define CSEN0_default false
// CAPSENSE Channel 1 is
#define CSEN1_port gpioPortC
#define CSEN1_pin  1u
#define CSEN1_default false
// CAPSENSE Channel 2 is
#define CSEN2_port gpioPortC
#define CSEN2_pin  2u
#define CSEN2_default false
// CAPSENSE Channel 3 is
#define CSEN3_port gpioPortC
#define CSEN3_pin  3u
#define CSEN3_default false

#define DIR_FLAG_SET 02u

struct direction_data{
  uint8_t direction;
  uint8_t dir_time;
};

extern OS_MUTEX DIRECTION_SET_MUTEX;


typedef enum {NO_DIR, SOFT_LEFT, HARD_LEFT, SOFT_RIGHT, HARD_RIGHT}SLIDER_FLAG;
//***********************************************************************************
// global variables
//***********************************************************************************
extern SLIDER_FLAG capsense_data;
/***************************************************************************//**
 * Initialize button
 ******************************************************************************/
void slider_init(void);

#endif  // SLIDERINPUT_H

/***************************************************************************//**
 * @file
 * @brief WRITELED examples functions
 ******************************************************************************/

#ifndef WRITELED_H
#define WRITELED_H



#define WRITELED_TASK_STACK_SIZE      128

#define WRITELED_TASK_PRIO            20

/***************************************************************************//**
 * Initialize WRITELED
 ******************************************************************************/
void writeled_init(void);

#endif  // WRITELED_H

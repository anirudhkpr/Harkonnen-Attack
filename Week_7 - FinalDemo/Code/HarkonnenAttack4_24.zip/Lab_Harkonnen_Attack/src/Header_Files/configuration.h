/***************************************************************************//**
 * @file
 * @brief Idle functions
 ******************************************************************************/

#ifndef IDLE_H
#define IDLE_H

#include "gpio.h"

#define IDLE_TASK_STACK_SIZE      96

#define IDLE_TASK_PRIO            5

#define GRAVITY                   0

#define MAXFORCE                  8
#define MIDFORCE                  4

struct gconfigv4{
  uint8_t version;
  uint8_t TauPhysics;
  uint8_t TauLCD;
  uint16_t gravity;
  uint32_t canyonsize;
  struct holtzmanMassesConfig {
   uint8_t num;
   uint16_t DisplayDiameter;
   uint8_t InitialConditions;
   struct InitialVelocity{
     int16_t xvel;
     int16_t yvel;
   }MassSpeed;
   int8_t InitialHorizontalPosition;
   uint32_t UserDefinedModeInput[7];
  } Mass;
  struct Platform{
    uint32_t MaxForce;
    uint8_t  Mass;
    uint16_t Length;
    struct BounceFromCanyonWalls{
     bool Enabled;
     bool Limited;
     uint8_t MaxPlatformBounceSpeed;
    }BounceToggle;
    bool AutomaticControl;
  }PlatformCharacteristics;
  struct HoltzManShield{
    uint16_t  MinimumEffectivePerpendicularSpeed;
    uint8_t   ExclusivelyPassiveBounceKineticEnergyReduction;
    struct Boost{
      uint8_t KineticEnergyIncrease;
      uint16_t  ArmingWindowBeforeImpact;
      uint16_t RechargeTimeAfterDisarm;
    }BoostCharacteristics;
    struct Laser{
      uint8_t NumActivations;
      bool AutomaticControl;
    }LaserCharacteristics;
  }ShieldCharacteristics;


};
/***************************************************************************//**
 * Initialize idle example
 ******************************************************************************/
//void idle_init(void);

#endif  // IDLE_H

/***************************************************************************//**
 * @file
 * @brief Button functionality
 ******************************************************************************/

#include "os.h"
#include "sliderinput.h"
#include "speed_setpoint.h"
#include "app.h"
/*******************************************************************************
 ***************************  LOCAL VARIABLES   ********************************
 ******************************************************************************/

static OS_TCB tcb;
static CPU_STK stack[SLIDER_TASK_STACK_SIZE];
//static OS_SEM SLIDER_SEM;
//static OS_TMR SLIDER_TMR;
/*******************************************************************************
 ***************************  GLOBAL VARIABLES   ********************************
 ******************************************************************************/
SLIDER_FLAG capsense_data;
OS_MUTEX DIRECTION_SET_MUTEX;

/*******************************************************************************
 *********************   LOCAL FUNCTION PROTOTYPES   ***************************
 ******************************************************************************/

static void slider_task(void *arg);

/*******************************************************************************
 **************************   GLOBAL FUNCTIONS   *******************************
 ******************************************************************************/
/***************************************************************************//**
 * @brief
 *   Timer Callback Function
 ******************************************************************************/
void TMR_Callbackfn(OS_TMR  *p_tmr, void  *p_arg)
{
  PP_UNUSED_PARAM(p_arg);
  PP_UNUSED_PARAM(p_tmr);
  RTOS_ERR err;
//  OSSemPost(&SLIDER_SEM, OS_OPT_POST_ALL, &err);

  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}

/***************************************************************************//**
 * Initialize slider example.
 ******************************************************************************/
void slider_init(void)
{
  RTOS_ERR err;

  // Create slider Task
  OSTaskCreate(&tcb,
               "slider task",
               slider_task,
               DEF_NULL,
               SLIDER_TASK_PRIO,
               &stack[0],
               (SLIDER_TASK_STACK_SIZE / 10u),
               SLIDER_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

//  OSSemCreate(&SLIDER_SEM,"Slider Semaphore", 0,&err);
//  /*   Check error code.                                  */
//  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
//
//  OSTmrCreate(&SLIDER_TMR,"Slider Timer",1,10,OS_OPT_TMR_PERIODIC, (OS_TMR_CALLBACK_PTR) TMR_Callbackfn,NULL,&err);
//  /*   Check error code.                                  */
//  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
//
//  OSMutexCreate(&DIRECTION_SET_MUTEX, "Direction Set Mutex", &err);
//  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  capsense_data = NO_DIR;

}

/***************************************************************************//**
 * slider task.
 ******************************************************************************/
static void slider_task(void *arg)
{
    PP_UNUSED_PARAM(arg);

    RTOS_ERR err;
//    OSTmrStart(&SLIDER_TMR,&err);
    while (1)
    {
        OSTimeDly(50, OS_OPT_TIME_DLY, &err);
//        OSSemPend(&SLIDER_SEM,0,OS_OPT_PEND_BLOCKING,NULL,&err);
//        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
        CAPSENSE_Sense();
//        OSMutexPend(&DIRECTION_SET_MUTEX, 0, OS_OPT_PEND_BLOCKING ,NULL, &err);
//        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
        if(CAPSENSE_getPressed(CSEN0_pin) & (! CAPSENSE_getPressed(CSEN2_pin)) & (! CAPSENSE_getPressed(CSEN3_pin))){ //Set according to pressed pin
            capsense_data = HARD_LEFT;
        }
        else if(CAPSENSE_getPressed(CSEN1_pin) & (! CAPSENSE_getPressed(CSEN2_pin)) & (! CAPSENSE_getPressed(CSEN3_pin))){
            capsense_data = SOFT_LEFT;
        }
        else if(CAPSENSE_getPressed(CSEN2_pin) & (! CAPSENSE_getPressed(CSEN0_pin)) & (! CAPSENSE_getPressed(CSEN1_pin))){

            capsense_data = SOFT_RIGHT;
        }
        else if(CAPSENSE_getPressed(CSEN3_pin) & (! CAPSENSE_getPressed(CSEN0_pin)) & (! CAPSENSE_getPressed(CSEN1_pin))){
            capsense_data = HARD_RIGHT;
        }
        else{
            capsense_data = NO_DIR; //If nothing is pressed, set to default to turn off LED
        }
//        OSMutexPost(&DIRECTION_SET_MUTEX, OS_OPT_POST_NONE, &err);
//        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
//        OSFlagPost(&DATA_UPDATED_FLAG, DIR_FLAG_SET,OS_OPT_POST_FLAG_SET, &err);
//        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
    }
}

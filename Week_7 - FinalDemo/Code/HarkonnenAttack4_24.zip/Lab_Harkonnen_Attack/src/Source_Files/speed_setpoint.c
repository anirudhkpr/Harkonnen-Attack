/***************************************************************************//**
 * @file
 * @brief Idle functions
 ******************************************************************************/
#include "os.h"
#include "em_emu.h"
#include "em_core.h"
#include "speed_setpoint.h"
#include "sliderinput.h"
#include "button.h"
/*******************************************************************************
 ***************************  LOCAL VARIABLES   ********************************
 ******************************************************************************/

static OS_TCB tcb;
static CPU_STK stack[SPEED_SETPOINT_TASK_STACK_SIZE];

struct speed_data speed_set_data;
OS_MUTEX SPEED_SET_MUTEX;
OS_FLAG_GRP DATA_UPDATED_FLAG;

/*******************************************************************************
 *********************   LOCAL FUNCTION PROTOTYPES   ***************************
 ******************************************************************************/

static void speed_setpoint_task(void *arg);

/*******************************************************************************
 **************************   GLOBAL FUNCTIONS   *******************************
 ******************************************************************************/

/***************************************************************************//**
 * Initialize idle example.
 ******************************************************************************/
void speed_setpoint_init(void)
{
  RTOS_ERR err;

  // Create Blink Task
  OSTaskCreate(&tcb,
               "speed setpoint task",
               speed_setpoint_task,
               DEF_NULL,
               SPEED_SETPOINT_TASK_PRIO,
               &stack[0],
               (SPEED_SETPOINT_TASK_STACK_SIZE / 10u),
               SPEED_SETPOINT_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  speed_set_data.dec = 0;
  speed_set_data.inc = 0;
  speed_set_data.speed = 0;

  OSMutexCreate(&SPEED_SET_MUTEX, "Speed Set Mutex", &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  OSFlagCreate(&DATA_UPDATED_FLAG,"Data Updated Flag",0,&err);
  /*   Check error code.                                  */
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}

/***************************************************************************//**
 * Blink task.
 ******************************************************************************/
static void speed_setpoint_task(void *arg)
{
////    PP_UNUSED_PARAM(arg);
////
////    RTOS_ERR err;
////    while (1)
////    {
////        OSSemPend(&BTN_PRESS_SEM,0,OS_OPT_PEND_BLOCKING,NULL,&err);
////        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
////        OSMutexPend(&SPEED_SET_MUTEX, 0, OS_OPT_PEND_BLOCKING ,NULL, &err);
////        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
////        CORE_CriticalDisableIrq();
////        OSIntEnter();
//////        uint8_t btn0 = ReadFifoStr(&btn0_data);
//////        uint8_t btn1 = ReadFifoStr(&btn1_data);
////        if(btn0 == BUTTON0_PRESS){
////            speed_set_data.inc++;
////            speed_set_data.speed +=5;
////        }
////        if(btn1 == BUTTON1_PRESS){
////            speed_set_data.dec++;
////            speed_set_data.speed -=5;
////        }
////        OSFlagPost(&DATA_UPDATED_FLAG, SPEED_FLAG_SET,OS_OPT_POST_FLAG_SET, &err);
////        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
////
////        OSIntExit();
////        CORE_CriticalEnableIrq();
////        OSMutexPost(&SPEED_SET_MUTEX, OS_OPT_POST_NONE, &err);
////        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
//    }
}

/***************************************************************************//**
 * @file
 * @brief Button functionality
 ******************************************************************************/

#include "os.h"
#include "speed_setpoint.h"
#include "sliderinput.h"
#include "vehiclemonitor.h"
#include "app.h"
/*******************************************************************************
 ***************************  LOCAL VARIABLES   ********************************
 ******************************************************************************/

static OS_TCB tcb;
static CPU_STK stack[VEHICLEMONITOR_TASK_STACK_SIZE];
OS_FLAG_GRP ALERT_EVENT_FLAG;
uint8_t lastspeed = 0;
uint8_t lastdir = NO_DIR;
uint8_t lasttime = 0;
/*******************************************************************************
 ***************************  GLOBAL VARIABLES   ********************************
 ******************************************************************************/

/*******************************************************************************
 *********************   LOCAL FUNCTION PROTOTYPES   ***************************
 ******************************************************************************/

static void vehicle_monitor_task(void *arg);

/*******************************************************************************
 **************************   GLOBAL FUNCTIONS   *******************************
 ******************************************************************************/


/***************************************************************************//**
 * Initialize slider example.
 ******************************************************************************/
void vehicle_monitor_init(void)
{
  RTOS_ERR err;

  // Create slider Task
  OSTaskCreate(&tcb,
               "vehicle monitor task",
               vehicle_monitor_task,
               DEF_NULL,
               VEHICLEMONITOR_TASK_PRIO,
               &stack[0],
               (VEHICLEMONITOR_TASK_STACK_SIZE / 10u),
               VEHICLEMONITOR_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);

  OSFlagCreate(&ALERT_EVENT_FLAG,"Alert Event Flags",0,&err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));



}

/***************************************************************************//**
 * slider task.
 ******************************************************************************/
static void vehicle_monitor_task(void *arg)
{
    PP_UNUSED_PARAM(arg);

    RTOS_ERR err;
    while (1)
    {
        uint8_t flag = OSFlagPend(&DATA_UPDATED_FLAG, 0x03,0,OS_OPT_PEND_FLAG_SET_ANY + OS_OPT_PEND_FLAG_CONSUME +OS_OPT_PEND_BLOCKING,NULL,&err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
        if(flag & 0x01){
            OSMutexPend(&SPEED_SET_MUTEX, 0, OS_OPT_PEND_BLOCKING ,NULL, &err);
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
            lastspeed = speed_set_data.speed;
            OSMutexPost(&SPEED_SET_MUTEX, OS_OPT_POST_NONE, &err);
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
        }
        if(flag & 0x02){
            OSMutexPend(&DIRECTION_SET_MUTEX, 0, OS_OPT_PEND_BLOCKING ,NULL, &err);
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
//            lastdir = capsense_data.direction;
//            lasttime = capsense_data.dir_time;
            OSMutexPost(&DIRECTION_SET_MUTEX, OS_OPT_POST_NONE, &err);
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
        }
        uint8_t flag_post_val = 0x00;
        if(((lastspeed > 45) & (lastdir!=NO_DIR))| (lasttime>5)){
            flag_post_val |= 0x02;
        }
        else{
            flag_post_val|= 0x08;
        }
        if(lastspeed > 75){
            flag_post_val|= 0x01;
        }
        else{
            flag_post_val|= 0x04;
        }
        OSFlagPost(&ALERT_EVENT_FLAG,flag_post_val,OS_OPT_POST_FLAG_SET,&err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));


    }
}

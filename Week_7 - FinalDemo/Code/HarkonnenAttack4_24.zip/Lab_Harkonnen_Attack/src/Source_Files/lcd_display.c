/***************************************************************************//**
 * @file
 * @brief Button functionality
 ******************************************************************************/

#include "os.h"
#include "app.h"
#include "lcd_display.h"
#include "glib.h"
#include "sliderinput.h"
#include "dmd.h"
#include "speed_setpoint.h"
#include <string.h>
#include <stdio.h>
#include "sl_board_control.h"
#include "physics.h"
/*******************************************************************************
 ***************************  LOCAL VARIABLES   ********************************
 ******************************************************************************/

static OS_TCB tcb;
static CPU_STK stack[LCD_TASK_STACK_SIZE];
static OS_SEM LCD_SEM;
static OS_TMR LCD_TMR;

static GLIB_Context_t glibContext;
static uint8_t dispspeed = 0;
static uint8_t dispdir = NO_DIR;
/*******************************************************************************
 ***************************  GLOBAL VARIABLES   ********************************
 ******************************************************************************/


/*******************************************************************************
 *********************   LOCAL FUNCTION PROTOTYPES   ***************************
 ******************************************************************************/

static void lcd_task(void *arg);

/*******************************************************************************
 **************************   GLOBAL FUNCTIONS   *******************************
 ******************************************************************************/
/***************************************************************************//**
 * @brief
 *   Timer Callback Function
 ******************************************************************************/
void LCDTMR_Callbackfn(OS_TMR  *p_tmr, void  *p_arg)
{
  PP_UNUSED_PARAM(p_arg);
  PP_UNUSED_PARAM(p_tmr);
  RTOS_ERR err;
  OSSemPost(&LCD_SEM, OS_OPT_POST_ALL, &err);

  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}

/***************************************************************************//**
 * Initialize slider example.
 ******************************************************************************/
void lcd_init(void)
{
  RTOS_ERR err;
  uint32_t status;
  /* Enable the memory lcd */
  status = sl_board_enable_display();
  EFM_ASSERT(status == SL_STATUS_OK);

  /* Initialize the DMD support for memory lcd display */
  status = DMD_init(0);
  EFM_ASSERT(status == DMD_OK);

  /* Initialize the glib context */
  status = GLIB_contextInit(&glibContext);
  EFM_ASSERT(status == GLIB_OK);

  glibContext.backgroundColor = White;
  glibContext.foregroundColor = Black;

  /* Fill lcd with background color */
  GLIB_clear(&glibContext);

  /* Use Narrow font */
  GLIB_setFont(&glibContext, (GLIB_Font_t *) &GLIB_FontNarrow6x8);

  // Create slider Task
  OSTaskCreate(&tcb,
               "LCD task",
               lcd_task,
               DEF_NULL,
               LCD_TASK_PRIO,
               &stack[0],
               (LCD_TASK_STACK_SIZE / 10u),
               LCD_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

//  OSSemCreate(&LCD_SEM,"LCD Semaphore", 0,&err);
//  /*   Check error code.                                  */
//  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
//
//  OSTmrCreate(&LCD_TMR,"LCD Timer",1,50,OS_OPT_TMR_PERIODIC, (OS_TMR_CALLBACK_PTR) LCDTMR_Callbackfn,NULL,&err);
//  /*   Check error code.                                  */
//  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

}

/***************************************************************************//**
 * slider task.
 ******************************************************************************/
static void lcd_task(void *arg)
{
    PP_UNUSED_PARAM(arg);

    RTOS_ERR err;
//    OSTmrStart(&LCD_TMR,&err);
    while (1)
    {
        OSTimeDly(150, OS_OPT_TIME_DLY, &err);
//        OSSemPend(&LCD_SEM,0,OS_OPT_PEND_BLOCKING,NULL,&err);
//        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
//
//        OSMutexPend(&SPEED_SET_MUTEX, 0, OS_OPT_PEND_BLOCKING ,NULL, &err);
//        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
//        dispspeed = speed_set_data.speed;
//        OSMutexPost(&SPEED_SET_MUTEX, OS_OPT_POST_NONE, &err);
//        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
//
//        OSMutexPend(&DIRECTION_SET_MUTEX, 0, OS_OPT_PEND_BLOCKING ,NULL, &err);
//        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
//        dispdir = capsense_data.direction;
//        OSMutexPost(&DIRECTION_SET_MUTEX, OS_OPT_POST_NONE, &err);
//        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
//        char speed[5];
//        char dir[20];
        char printstr[50] = "______";
//        strcpy(printstr, "speed:");
//        sprintf(speed, "%d", dispspeed);
//        strcat(printstr, speed);
//        if(dispdir==NO_DIR){
//            strcpy(dir, "Dir: Straight");
//        }
//        else if(dispdir==SOFT_LEFT){
//            strcpy(dir, "Dir: Gradual left");
//        }
//        else if(dispdir==HARD_LEFT){
//            strcpy(dir, "Dir: Sharp left");
//        }
//        else if(dispdir==SOFT_RIGHT){
//            strcpy(dir, "Dir: Gradual right");
//        }
//        else if(dispdir==HARD_RIGHT){
//            strcpy(dir, "Dir: Sharp right");
//        }
        GLIB_clear(&glibContext);

        GLIB_drawChar(&glibContext, 'O', mass_pos.x, mass_pos.y,
                               true);
        GLIB_drawString(&glibContext, printstr, 6,
                                 shieldpos_data, 120, true);

//        GLIB_drawStringOnLine(&glibContext,
//                               printstr,
//                               0,
//                               GLIB_ALIGN_LEFT,
//                               5,
//                               5,
//                               true);
//        GLIB_drawStringOnLine(&glibContext,
//                               dir,
//                               1,
//                               GLIB_ALIGN_LEFT,
//                               5,
//                               5,
//                               true);
        DMD_updateDisplay();
    }
}

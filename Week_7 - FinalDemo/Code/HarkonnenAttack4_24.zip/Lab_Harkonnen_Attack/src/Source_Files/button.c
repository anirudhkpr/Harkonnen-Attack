/***************************************************************************//**
 * @file
 * @brief Button functionality
 ******************************************************************************/

#include "os.h"
#include "button.h"
#include "app.h"
#include "gpio.h"
/*******************************************************************************
 ***************************  LOCAL VARIABLES   ********************************
 ******************************************************************************/

/*******************************************************************************
 ***************************  GLOBAL VARIABLES   ********************************
 ******************************************************************************/
//bool btn0 = false;
//bool btn1 = false;
//static uint16_t btnpress;
//static OS_FLAG_GRP BUTTON_FLAG_GRP;
OS_SEM BTN_PRESS_SEM;
BUTTON_FLAG button_val;
/*******************************************************************************
 *********************   LOCAL FUNCTION PROTOTYPES   ***************************
 ******************************************************************************/



/*******************************************************************************
 **************************   GLOBAL FUNCTIONS   *******************************
 ******************************************************************************/

/***************************************************************************//**
 * Initialize button example.
 ******************************************************************************/
void button_init(void)
{
  RTOS_ERR err;
  OSSemCreate(&BTN_PRESS_SEM,"Button Press Semaphore", 0,&err);
  /*   Check error code.                                  */
  button_val = NONE;
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

}

/***************************************************************************//**
 * @brief
 *   Interrupt handler to service pressing of buttons
 ******************************************************************************/
void GPIO_EVEN_IRQHandler(void)
{

  OSIntEnter();
  RTOS_ERR err;
//  OSFlagPost(&BUTTON_FLAG_GRP, BUTTON0_PRESS,OS_OPT_POST_FLAG_SET, &err);
//  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
  button_val = BUTTON0_PRESS;
  GPIO_PinOutSet(LED0_port, LED0_pin);
  GPIO_PinOutClear(LED1_port, LED1_pin);
  GPIO->IFC = 0xFFFFFFFF;
  OSIntExit();
}

/***************************************************************************//**
 * @brief
 *   Interrupt handler to service pressing of buttons
 ******************************************************************************/
void GPIO_ODD_IRQHandler(void)
{
  OSIntEnter();
  RTOS_ERR err;
//  OSFlagPost(&BUTTON_FLAG_GRP, BUTTON1_PRESS,OS_OPT_POST_FLAG_SET, &err);
//  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
  button_val = BUTTON1_PRESS;
  GPIO_PinOutSet(LED1_port, LED1_pin);
  GPIO_PinOutClear(LED0_port, LED0_pin);
  GPIO->IFC = 0xFFFFFFFF;
  OSIntExit();
}


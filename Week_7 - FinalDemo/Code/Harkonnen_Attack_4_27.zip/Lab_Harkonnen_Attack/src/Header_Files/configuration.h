/***************************************************************************//**
 * @file
 * @brief Idle functions
 ******************************************************************************/

#ifndef CONFIG_H
#define CONFIG_H

#include "gpio.h"

#define IDLE_TASK_STACK_SIZE      96

#define IDLE_TASK_PRIO            5

typedef struct gconfigv4{
  uint32_t version;
  uint32_t TauPhysics;
  uint32_t TauLCD;
  uint32_t gravity;
  uint32_t canyonsize;
  struct holtzmanMassesConfig {
    uint32_t num;
    uint32_t DisplayDiameter;
    uint32_t InitialConditions;
    struct InitialVelocity{
      int32_t xvel;
      int32_t yvel;
    }MassSpeed;
    int32_t InitialHorizontalPosition;
    uint32_t UserDefinedModeInput[8];
  } Mass;
  struct Platform{
    uint32_t MaxForce;
    uint32_t  Mass;
    uint32_t Length;
    struct BounceFromCanyonWalls{
      bool Enabled;
      bool Limited;
      uint32_t MaxPlatformBounceSpeed;
    }BounceToggle;
    bool AutomaticControl;
  }PlatformCharacteristics;
  struct HoltzManShield{
    uint32_t  MinimumEffectivePerpendicularSpeed;
    uint32_t   ExclusivelyPassiveBounceKineticEnergyReduction;
    struct Boost{
      uint32_t KineticEnergyIncrease;
      uint32_t  ArmingWindowBeforeImpact;
      uint32_t RechargeTimeAfterDisarm;
    }BoostCharacteristics;
    struct Laser{
      uint32_t NumActivations;
      bool AutomaticControl;
    }LaserCharacteristics;
  }ShieldCharacteristics;
} gconfigv4_t;

extern gconfigv4_t ConfigData;
/***************************************************************************//**
 * Initialize idle example
 ******************************************************************************/
//void idle_init(void);

#endif  // IDLE_H

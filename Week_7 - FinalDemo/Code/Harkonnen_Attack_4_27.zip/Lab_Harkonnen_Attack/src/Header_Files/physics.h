/***************************************************************************//**
 * @file
 * @brief PHYSICS functions
 ******************************************************************************/

#ifndef PHYSICS_H
#define PHYSICS_H

#include "gpio.h"
#include "sliderinput.h"
#include "button.h"

#define PHYSICS_TASK_STACK_SIZE      128

#define PHYSICS_TASK_PRIO            20

#define GRAVITY                   1

/***************************************************************************//**
 * Initialize PHYSICS example
 ******************************************************************************/
void physics_init(void);

struct massposition_data{
  int32_t x;
  int32_t y;
};

struct massvelocity_data{
  int32_t x;
  int32_t y;
};

extern struct massposition_data mass_pos;
//extern struct shield_data;
extern uint32_t shieldpos_data;

bool MassStep(struct massposition_data* mass_pos, struct massvelocity_data* mass_vel);
bool ShieldStep(uint32_t* shield_pos, int32_t* shield_vel, int32_t shield_acc);
bool CollisionTest(uint32_t shield_pos,struct massposition_data mass_pos);
#endif  // PHYSICS_H

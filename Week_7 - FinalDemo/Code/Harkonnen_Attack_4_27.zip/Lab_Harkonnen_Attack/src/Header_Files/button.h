/***************************************************************************//**
 * @file
 * @brief Button functionality
 ******************************************************************************/


#ifndef BUTTON_H
#define BUTTON_H

#include "em_gpio.h"
#include "os.h"

#define BUTTON_TASK_STACK_SIZE      128

#define BUTTON_TASK_PRIO            20

#define BUTTON0_PORT               gpioPortF
#define BUTTON1_PORT               gpioPortF
#define BTN0_MASK 0x40
#define BTN1_MASK 0x80

typedef enum {NONE, BUTTON0_PRESS, BUTTON1_PRESS} BUTTON_FLAG;


//***********************************************************************************
// global variables
//***********************************************************************************
//extern OS_SEM BTN_PRESS_SEM;
extern OS_FLAG_GRP BUTTON_FLAG_GRP;
/***************************************************************************//**
 * Initialize button
 ******************************************************************************/
void button_init(void);

#endif  // BUTTON_H

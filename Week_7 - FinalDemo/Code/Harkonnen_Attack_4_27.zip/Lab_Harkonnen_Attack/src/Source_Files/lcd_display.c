/***************************************************************************//**
 * @file
 * @brief Button functionality
 ******************************************************************************/

#include "os.h"
#include "app.h"
#include "lcd_display.h"
#include "glib.h"
#include "sliderinput.h"
#include "dmd.h"
#include <string.h>
#include <stdio.h>
#include "sl_board_control.h"
#include "physics.h"
#include "configuration.h"
#include "cmu.h"
/*******************************************************************************
 ***************************  LOCAL VARIABLES   ********************************
 ******************************************************************************/

static OS_TCB tcb;
static CPU_STK stack[LCD_TASK_STACK_SIZE];
static GLIB_Context_t glibContext;
static uint32_t pxsize;
uint8_t mass_size;
static uint8_t length;

OS_FLAG_GRP GAMEMODE;
/*******************************************************************************
 ***************************  GLOBAL VARIABLES   ********************************
 ******************************************************************************/


/*******************************************************************************
 *********************   LOCAL FUNCTION PROTOTYPES   ***************************
 ******************************************************************************/

static void lcd_task(void *arg);

/*******************************************************************************
 **************************   GLOBAL FUNCTIONS   *******************************
 ******************************************************************************/

/***************************************************************************//**
 * Initialize slider example.
 ******************************************************************************/
void lcd_init(void)
{
  RTOS_ERR err;
  uint32_t status;
  /* Enable the memory lcd */
  status = sl_board_enable_display();
  EFM_ASSERT(status == SL_STATUS_OK);

  /* Initialize the DMD support for memory lcd display */
  status = DMD_init(0);
  EFM_ASSERT(status == DMD_OK);

  /* Initialize the glib context */
  status = GLIB_contextInit(&glibContext);
  EFM_ASSERT(status == GLIB_OK);

  glibContext.backgroundColor = White;
  glibContext.foregroundColor = Black;

  /* Fill lcd with background color */
  GLIB_clear(&glibContext);

  /* Use Narrow font */
  GLIB_setFont(&glibContext, (GLIB_Font_t *) &GLIB_FontNarrow6x8);

  // Create slider Task
  OSTaskCreate(&tcb,
               "LCD task",
               lcd_task,
               DEF_NULL,
               LCD_TASK_PRIO,
               &stack[0],
               (LCD_TASK_STACK_SIZE / 10u),
               LCD_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
  pxsize = ConfigData.canyonsize / 128;
  mass_size = ConfigData.Mass.DisplayDiameter/pxsize;
  mass_size/=2;
  if(mass_size == 0){
      mass_size = 3;
  }
  length = ConfigData.PlatformCharacteristics.Length/pxsize;
  if(length == 0){
      length = 20;
  }

  OSFlagCreate (&GAMEMODE,
                      "LCD",
                      0,
                      &err);
}

/***************************************************************************//**
 * slider task.
 ******************************************************************************/
static void lcd_task(void *arg)
{
    PP_UNUSED_PARAM(arg);

    RTOS_ERR err;
    char printstr1[20] = "Game Over RIP";
    char printstr2[20] = "You win!";
    char printstr3[20] = "Erroneous Config";
    while (1)
    {
        OSTimeDly(ConfigData.TauLCD, OS_OPT_TIME_DLY, &err);
        GLIB_clear(&glibContext);
        OS_FLAGS  LCD_FLAGS;
        LCD_FLAGS = OSFlagPend(&GAMEMODE,
                                0x07,
                                0,
                                OS_OPT_PEND_FLAG_SET_ANY + OS_OPT_PEND_FLAG_CONSUME + OS_OPT_PEND_NON_BLOCKING,
                                NULL,
                                &err);
        if(LCD_FLAGS & 0x01){
            GLIB_drawStringOnLine(&glibContext,
                                   printstr1,
                                   0,
                                   GLIB_ALIGN_LEFT,
                                   5,
                                   5,
                                   true);
            DMD_updateDisplay();
            while(true);
        }
        else if(LCD_FLAGS & 0x02){
            GLIB_drawStringOnLine(&glibContext,
                                   printstr2,
                                   0,
                                   GLIB_ALIGN_LEFT,
                                   5,
                                   5,
                                   true);
            DMD_updateDisplay();
            while(true);
        }
        else if(LCD_FLAGS & 0x04){
            GLIB_drawStringOnLine(&glibContext,
                                   printstr3,
                                   0,
                                   GLIB_ALIGN_LEFT,
                                   5,
                                   5,
                                   true);
            DMD_updateDisplay();
            while(true);
        }
        for(uint8_t i = 0; i<128;i++){
            GLIB_drawPixel(&glibContext, 2, i);
            GLIB_drawPixel(&glibContext, 125, i);
        }
        for(uint8_t i = 0; i<length;i++){
            GLIB_drawPixel(&glibContext, shieldpos_data/pxsize + i, 126);
            GLIB_drawPixel(&glibContext, shieldpos_data/pxsize + i, 125);
        }
        for(uint32_t i = 0;i <= mass_size; i++){
//        for(uint32_t i = 0;i < 314; i+=31){
//            uint32_t var1 =  4*i*(314-i);
//            uint32_t var2 =  4*var1;
//            var1 = 493480- var1;
//            uint8_t sinvalue = (8*var2)/var1;
//            var1 = 64-(sinvalue*sinvalue);
//            var2 = var1/2;
//            uint8_t cosvalue = 0;
//            for(uint32_t j = 0;j<var2; j++){
//                if(j*j >= var1){
//                    cosvalue = j;
//                    break;
//                }
//            }
            uint32_t var1 = i/2;
            for(uint32_t j = 0;j<var1; j++){
                if(j*j >= i){
                    var1 = j;
                    break;
                }
            }
            GLIB_drawPixel(&glibContext, mass_pos.x/pxsize + i, mass_pos.y/pxsize + var1);
            GLIB_drawPixel(&glibContext, mass_pos.x/pxsize - i, mass_pos.y/pxsize + var1);
            GLIB_drawPixel(&glibContext, mass_pos.x/pxsize + i, mass_pos.y/pxsize - var1);
            GLIB_drawPixel(&glibContext, mass_pos.x/pxsize - i, mass_pos.y/pxsize - var1);
        }
//                               true);
//        GLIB_drawStringOnLine(&glibContext,
//                               dir,
//                               1,
//                               GLIB_ALIGN_LEFT,
//                               5,
//                               5,
//                               true);
        DMD_updateDisplay();
    }
}

///***************************************************************************//**
// * @file
// * @brief Button functionality
// ******************************************************************************/
//
//#include "os.h"
//#include "unit_test.h"
//#include "app.h"
//#include "physics.h"
///*******************************************************************************
// ***************************  LOCAL VARIABLES   ********************************
// ******************************************************************************/
//
///*******************************************************************************
// ***************************  GLOBAL VARIABLES   ********************************
// ******************************************************************************/
//
///*******************************************************************************
// *********************   LOCAL FUNCTION PROTOTYPES   ***************************
// ******************************************************************************/
//
//
//
///*******************************************************************************
// **************************   GLOBAL FUNCTIONS   *******************************
// ******************************************************************************/
//
///***************************************************************************//**
// * Initialize button example.
// ******************************************************************************/
//void unit_test(void)
//{
//  struct massposition_data mass_pos;
//  struct massvelocity_data mass_vel;
//  static uint16_t test_flag = 0;
//  bool teststatus = false;
//  //Test 1: Out of Bounds Test
//  mass_pos.x = 0;
//  mass_pos.y = 128;
//  mass_vel.x = 0;
//  mass_vel.y = 0;
////  teststatus = MassStep(&mass_pos, mass_vel);
//  if(teststatus){
//      test_flag +=1;
//  }
//  //Test 2: Velocity Test
//  for(uint8_t i = 1;i<129;i++){
//      mass_pos.x = 0;
//      mass_pos.y = 0;
//      mass_vel.x = 0;
//      mass_vel.y = i;
//      uint8_t temp = 128/i;
//      uint8_t count = 0;
////      while(MassStep(&mass_pos, mass_vel)){count++;}
//      if((count == temp)|(count == temp + 1)){
//          continue;
//      }
//      else{
//          test_flag +=2;
//          break;
//      }
//  }
//
//  //Test 3:Shield out of bound Test
//  uint8_t shieldpos = 0;
//  uint8_t shieldvel = 0;
//  teststatus = ShieldStep(&shieldpos, &shieldvel, 0);
//  if(teststatus){
//      test_flag +=4;
//  }
//
//  //Test 4:Shield out of bound Test
//  shieldpos = 129;
//  shieldvel = 0;
//  teststatus = ShieldStep(&shieldpos, &shieldvel, 0);
//  if(teststatus){
//      test_flag +=8;
//  }
//
//  //Test 5:Constant Velocity Test
//  for(uint8_t i = 1;i<129;i++){
//      shieldpos = 5;
//      shieldvel = i;
//      uint8_t temp = 128/i;
//      uint8_t count = 5;
//      while(ShieldStep(&shieldpos, &shieldvel, 0)){
//          count++;
//      }
//      if((count == temp)|(count == temp + 1)){
//          continue;
//      }
//      else{
//          test_flag +=16;
//          break;
//      }
//  }
//
//  //Test 6:Constant Acceleration Test
//  for(uint8_t i = 1;i<129;i++){
//      shieldpos = 0;
//      shieldvel = 0;
//      uint8_t temp = sqrt(255/i);
//      uint8_t count = 0;
//      while(ShieldStep(&shieldpos, &shieldvel, i)){count++;}
//      if((count != temp)|(count != temp + 1)){
//          test_flag +=32;
//          break;
//      }
//  }
//
//  //Test 7: No Collision occurs (Within screen)
//  mass_pos.x = 0;
//  mass_pos.y = 0;
//  shieldpos = 100;
//  teststatus = CollisionTest(shieldpos,mass_pos);
//  if(teststatus){
//      test_flag +=64;
//  }
//
//  //Test 8: No Collision occurs (outside screen and not colliding conditions)
//  mass_pos.x = 0;
//  mass_pos.y = 0;
//  shieldpos = 129;
//  teststatus = CollisionTest(shieldpos,mass_pos);
//  if(teststatus){
//      test_flag +=128;
//  }
//
//  //Test 9: No Collision occurs (outside screen and colliding conditions)
//  mass_pos.x = 129;
//  mass_pos.y = 0;
//  shieldpos = 129;
//  teststatus = CollisionTest(shieldpos,mass_pos);
//  if(teststatus){
//      test_flag +=256;
//  }
//
//
//  //Test 10: Collision occurs
//  mass_pos.x = 5;
//  mass_pos.y = 0;
//  shieldpos = 5;
//  teststatus = CollisionTest(shieldpos,mass_pos);
//  if(!teststatus){
//      test_flag +=512;
//  }
//
//  while(true);
//}

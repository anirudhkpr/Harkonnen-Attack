/***************************************************************************//**
 * @file
 * @brief Idle functions
 ******************************************************************************/
#include "os.h"
#include "em_emu.h"
#include "em_core.h"
#include "idle.h"
#include "lcd_display.h"
#include "configuration.h"
/*******************************************************************************
 ***************************  LOCAL VARIABLES   ********************************
 ******************************************************************************/


gconfigv4_t ConfigData;
/*******************************************************************************
 *********************   LOCAL FUNCTION PROTOTYPES   ***************************
 ******************************************************************************/



/*******************************************************************************
 **************************   GLOBAL FUNCTIONS   *******************************
 ******************************************************************************/

/***************************************************************************//**
 * Initialize idle example.
 ******************************************************************************/
void config_init(void)
{

 ConfigData = (gconfigv4_t){
        .version = 3,
        .TauPhysics = 120,
        .TauLCD = 50,
        .gravity = 9800/2,
        .canyonsize = 100000,
        .Mass =
        {
           .num =  3,
           .DisplayDiameter = 10000,
           .InitialConditions = 0,
           .MassSpeed =
           {
               .xvel = 2000,
               .yvel = 0
           },
           .InitialHorizontalPosition = 5000,
           .UserDefinedModeInput = {0,0,0,0,0,0,0,0}
        },
        .PlatformCharacteristics =
        {
            .MaxForce = 20000,
            .Mass = 5,
            .Length = 15000,
            .BounceToggle =
            {
                .Enabled = true,
                .Limited = false,
                .MaxPlatformBounceSpeed = 500
            }
        },
        .ShieldCharacteristics =
        {
            .MinimumEffectivePerpendicularSpeed = 1000,
            .ExclusivelyPassiveBounceKineticEnergyReduction = 20,
            .BoostCharacteristics =
            {
                .KineticEnergyIncrease = 40,
                .ArmingWindowBeforeImpact = 200,
                .RechargeTimeAfterDisarm = 1000
            },
        .LaserCharacteristics =
        {
            .NumActivations = 1,
            .AutomaticControl = false
        }
        }
   };

}


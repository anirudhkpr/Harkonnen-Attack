/***************************************************************************//**
 * @file
 * @brief Button functionality
 ******************************************************************************/

#include "os.h"
#include "button.h"
#include "app.h"
#include "gpio.h"
#include "configuration.h"
#include "physics.h"
/*******************************************************************************
 ***************************  LOCAL VARIABLES   ********************************
 ******************************************************************************/

/*******************************************************************************
 ***************************  GLOBAL VARIABLES   ********************************
 ******************************************************************************/
OS_FLAG_GRP BUTTON_FLAG_GRP;
static OS_TICK lastpress = 0;
/*******************************************************************************
 *********************   LOCAL FUNCTION PROTOTYPES   ***************************
 ******************************************************************************/



/*******************************************************************************
 **************************   GLOBAL FUNCTIONS   *******************************
 ******************************************************************************/

/***************************************************************************//**
 * Initialize button
 ******************************************************************************/
void button_init(void)
{
  RTOS_ERR err;
  OSFlagCreate (&BUTTON_FLAG_GRP,
                      "Button Flag Grp",
                      0,
                      &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

}



/***************************************************************************//**
 * @brief
 *   Interrupt handler to service pressing of buttons
 ******************************************************************************/
void GPIO_EVEN_IRQHandler(void)
{
  OSIntEnter();
  CORE_CriticalDisableIrq();
  RTOS_ERR err;
  OSFlagPost(&BUTTON_FLAG_GRP, BUTTON0_PRESS,OS_OPT_POST_FLAG_SET, &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
  GPIO->IFC = 0xFFFFFFFF;
  CORE_CriticalEnableIrq();
  OSIntExit();
}

/***************************************************************************//**
 * @brief
 *   Interrupt handler to service pressing of buttons
 ******************************************************************************/
void GPIO_ODD_IRQHandler(void)
{
  OSIntEnter();
  CORE_CriticalDisableIrq();
  RTOS_ERR err;
  OS_TICK curtime = OSTimeGet (&err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
  OS_RATE_HZ tickrate = OSTimeTickRateHzGet (&err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
  if(((curtime - lastpress)/tickrate)*1000 > ConfigData.ShieldCharacteristics.BoostCharacteristics.RechargeTimeAfterDisarm){
      lastpress = curtime;
      OSFlagPost(&BUTTON_FLAG_GRP, BUTTON1_PRESS,OS_OPT_POST_FLAG_SET, &err);
      EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
  }
  GPIO->IFC = 0xFFFFFFFF;
  CORE_CriticalEnableIrq();
  OSIntExit();
}


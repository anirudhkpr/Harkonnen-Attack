/***************************************************************************//**
 * @file
 * @brief Idle functions
 ******************************************************************************/
#include "os.h"
#include "em_emu.h"
#include "em_core.h"
#include "physics.h"
#include "sliderinput.h"
#include "button.h"
#include "configuration.h"
#include "math.h"
#include "lcd_display.h"
/*******************************************************************************
 ***************************  LOCAL VARIABLES   ********************************
 ******************************************************************************/

static OS_TCB tcb;
static CPU_STK stack[PHYSICS_TASK_STACK_SIZE];
struct massposition_data mass_pos;
struct massvelocity_data mass_vel;
uint32_t shieldpos_data;
int32_t shield_acc;
int32_t shield_vel;
float KEreduction;
float KEgain;
OS_FLAGS  BTN_FLAGS;
uint32_t uses;
OS_TMR LED_TMR;
uint8_t led0_timing = 1,led1_timing = 1,count =0, loss = 0;
uint16_t pxsize;
static uint32_t length;
static uint32_t maxacc;
static uint32_t massnum;
/*******************************************************************************
 *********************   LOCAL FUNCTION PROTOTYPES   ***************************
 ******************************************************************************/
static void physics_task(void *arg);

/*******************************************************************************
 **************************   GLOBAL FUNCTIONS   *******************************
 ******************************************************************************/
/***************************************************************************//**
 * @brief
 *   Timer Callback Function
 ******************************************************************************/

void TMR_Callbackfn(OS_TMR  *p_tmr, void  *p_arg)
{
  PP_UNUSED_PARAM(p_arg);
  PP_UNUSED_PARAM(p_tmr);
  if(count == 10){
      GPIO_PinOutClear(LED1_port, LED1_pin);
      loss++;
      if(loss == 2){
          GPIO_PinOutToggle(LED0_port, LED0_pin);
          loss = 0;
      }
  }
  if(count == 0 ){
      if(led0_timing == 1){
          GPIO_PinOutToggle(LED0_port, LED0_pin);
      }
      if(led0_timing == 1){
          GPIO_PinOutToggle(LED1_port, LED1_pin);
      }
      count++;
  }
  else if(count == 1){
      if(led1_timing != 3){
      GPIO_PinOutToggle(LED1_port, LED1_pin);
      }
      GPIO_PinOutToggle(LED0_port, LED0_pin);
      count = 0;
  }
}

/***************************************************************************//**
 * Initialize physics
 ******************************************************************************/
void physics_init(void)
{
  RTOS_ERR err;

//  // Create Physics
  OSTaskCreate(&tcb,
               "physics task",
               physics_task,
               DEF_NULL,
               PHYSICS_TASK_PRIO,
               &stack[0],
               (PHYSICS_TASK_STACK_SIZE / 10u),
               PHYSICS_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

  mass_pos.x = ConfigData.Mass.InitialHorizontalPosition/10;
  mass_pos.y = 0;
  mass_vel.x = ConfigData.Mass.MassSpeed.xvel;
  mass_vel.y = ConfigData.Mass.MassSpeed.yvel;
  shieldpos_data = 3*pxsize;
  shield_acc = 0;
  shield_vel = 0;

  KEreduction = (float) sqrt((100 - ConfigData.ShieldCharacteristics.ExclusivelyPassiveBounceKineticEnergyReduction))/10;
  KEgain = (float) sqrt((100 + ConfigData.ShieldCharacteristics.BoostCharacteristics.KineticEnergyIncrease))/10;
//  KEreduction = 0.5;
//  KEgain = 1.5;
  uses = ConfigData.ShieldCharacteristics.LaserCharacteristics.NumActivations;

    OSTmrCreate(&LED_TMR,"Physics LED Timer",1,10,OS_OPT_TMR_PERIODIC, (OS_TMR_CALLBACK_PTR) TMR_Callbackfn,NULL,&err);
    /*   Check error code.                                  */
    EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
    pxsize = ConfigData.canyonsize / 128;

    length = ConfigData.PlatformCharacteristics.Length;
    maxacc = ConfigData.PlatformCharacteristics.MaxForce / ConfigData.PlatformCharacteristics.Mass;
    massnum = ConfigData.Mass.num;


    if(!ConfigData.PlatformCharacteristics.BounceToggle.Enabled){
        OSFlagPost (&GAMEMODE,
                              0x04,
                              OS_OPT_POST_FLAG_SET,
                              &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
    }
    if(ConfigData.PlatformCharacteristics.AutomaticControl){
        OSFlagPost (&GAMEMODE,
                              0x04,
                              OS_OPT_POST_FLAG_SET,
                              &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
    }
    if(ConfigData.ShieldCharacteristics.LaserCharacteristics.AutomaticControl){
        OSFlagPost (&GAMEMODE,
                              0x04,
                              OS_OPT_POST_FLAG_SET,
                              &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
    }
}

/***************************************************************************//**
 * Blink task.
 ******************************************************************************/
static void physics_task(void *arg)
{
    PP_UNUSED_PARAM(arg);

    RTOS_ERR err;
    OSTmrStart(&LED_TMR,&err);
    EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
    while (1)
    {
          MassStep(&mass_pos,&mass_vel);
          switch(capsense_data){
            case NO_DIR:
              shield_acc = 0;
              led1_timing = 3;
              break;
            case SOFT_LEFT:
              led1_timing = 0;
              shield_acc = -1*maxacc/2;
              break;
            case HARD_LEFT:
              shield_acc = -1*maxacc;
              led1_timing = 1;
              break;
            case SOFT_RIGHT:
              led1_timing = 0;
              shield_acc = maxacc/2;
              break;
            case HARD_RIGHT:
              led1_timing = 1;
              shield_acc = maxacc;
              break;
          }
          if((mass_pos.x - shieldpos_data )/pxsize> 32*pxsize){
              led0_timing = 1;
          }
          else{
              led0_timing = 1;
          }
          ShieldStep(&shieldpos_data, &shield_vel,shield_acc);
          OS_FLAGS  BTN_FLAGS;
          BTN_FLAGS = OSFlagPend (&BUTTON_FLAG_GRP,
                                  BUTTON1_PRESS + BUTTON0_PRESS,
                                  0,
                                  OS_OPT_PEND_FLAG_SET_ANY + OS_OPT_PEND_NON_BLOCKING,
                                  NULL,
                                  &err);
          if((BTN_FLAGS == 3)& uses){
              count = 10;
              OSFlagPost (&GAMEMODE,
                                    0x01,
                                    OS_OPT_POST_FLAG_SET,
                                    &err);
              EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
          }
          else{
          BTN_FLAGS = OSFlagPend (&BUTTON_FLAG_GRP,
                                  BUTTON0_PRESS,
                                  0,
                                  OS_OPT_PEND_FLAG_SET_ANY + OS_OPT_PEND_NON_BLOCKING + OS_OPT_PEND_FLAG_CONSUME,
                                  NULL,
                                  &err);
          if((BTN_FLAGS == BUTTON0_PRESS )& uses){
              mass_pos.x = ConfigData.Mass.InitialHorizontalPosition/10;
              mass_pos.y = 0;
              mass_vel.x = ConfigData.Mass.MassSpeed.xvel;
              mass_vel.y = ConfigData.Mass.MassSpeed.yvel;
              uses--;
          }
          }
          if(mass_vel.y>ConfigData.ShieldCharacteristics.MinimumEffectivePerpendicularSpeed){
              if((mass_pos.y/pxsize > 125)&(mass_pos.y/pxsize < 200)){
                  if(CollisionTest(shieldpos_data, mass_pos)){
                      OS_FLAGS  BTN_FLAGS;
                      CPU_TS    timestamp;
                      CPU_INT64U usecs;
                      BTN_FLAGS = OSFlagPend (&BUTTON_FLAG_GRP,
                                              BUTTON1_PRESS,
                                              0,
                                              OS_OPT_PEND_FLAG_SET_ANY + OS_OPT_PEND_FLAG_CONSUME + OS_OPT_PEND_NON_BLOCKING,
                                              &timestamp,
                                              &err);
                      CPU_TS curtime = CPU_TS_Get32();
                      timestamp= curtime-timestamp;
                      usecs = CPU_TS32_to_uSec(timestamp);
                      if(usecs > 1000*(ConfigData.ShieldCharacteristics.BoostCharacteristics.ArmingWindowBeforeImpact)){
                          BTN_FLAGS = 0;
                      }
                      if(BTN_FLAGS & BUTTON1_PRESS){
                          mass_vel.y = -1*KEgain*mass_vel.y;
                      }
                      else{
                          mass_pos.y = 125*pxsize;
                          mass_vel.y = -1*KEreduction*mass_vel.y;
                      }
                  }
              }
          }
          if(mass_pos.y/pxsize > 150 ){
              count = 10;
              OSFlagPost (&GAMEMODE,
                                    0x01,
                                    OS_OPT_POST_FLAG_SET,
                                    &err);
              EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
          }
          else if(mass_pos.y/pxsize < 0){
              massnum--;
              mass_pos.x = ConfigData.Mass.InitialHorizontalPosition/10;
              mass_pos.y = 0;
              mass_vel.x = ConfigData.Mass.MassSpeed.xvel;
              mass_vel.y = ConfigData.Mass.MassSpeed.yvel;
          }
          if(massnum == 0){
              OSTmrDel (&LED_TMR,
                        &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
        GPIO_PinOutClear(LED1_port, LED1_pin);
        GPIO_PinOutClear(LED0_port, LED0_pin);
        OSFlagPost (&GAMEMODE,
                              0x02,
                              OS_OPT_POST_FLAG_SET,
                              &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
          }
        OSTimeDly(ConfigData.TauPhysics, OS_OPT_TIME_DLY, &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
    }
}

bool MassStep(struct massposition_data* mass_pos, struct massvelocity_data* mass_vel){
  mass_vel->y = mass_vel->y + ConfigData.gravity/10;
  mass_pos->x = mass_pos->x + mass_vel->x;
  mass_pos->y = mass_pos->y + mass_vel->y;
  if(ConfigData.PlatformCharacteristics.BounceToggle.Enabled){
    if(mass_pos->x/pxsize<3){
        mass_pos->x = 3*pxsize;
        mass_vel->x = -1*mass_vel->x;
    }
    else if(mass_pos->x/pxsize > 110){
        mass_pos->x = 110*pxsize;
        mass_vel->x = -1*mass_vel->x;
    }
  }
  return true;

}

bool ShieldStep(uint32_t* shield_pos, int32_t* shield_vel, int32_t shield_acc){
   *shield_pos = *shield_pos + *shield_vel + 0.5*shield_acc;
   if(*shield_pos/pxsize<8){
       *shield_pos = 8*pxsize;
       *shield_vel = 0;
   }
   if(*shield_pos/pxsize>110){
       *shield_pos = 110*pxsize;
       *shield_vel = 0;
   }
   *shield_vel = *shield_vel + shield_acc;
   return true;

}

bool CollisionTest(uint32_t shield_pos,struct massposition_data mass_pos){
  if((mass_pos.x >= shield_pos ) & (shield_pos + length >= mass_pos.x)){
      return true;
  }
  return false;
}

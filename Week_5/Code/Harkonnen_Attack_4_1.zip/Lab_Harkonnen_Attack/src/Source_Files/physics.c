/***************************************************************************//**
 * @file
 * @brief Idle functions
 ******************************************************************************/
#include "os.h"
#include "em_emu.h"
#include "em_core.h"
#include "physics.h"
#include "sliderinput.h"
#include "button.h"
#include "button_data.h"
/*******************************************************************************
 ***************************  LOCAL VARIABLES   ********************************
 ******************************************************************************/

//static OS_TCB tcb;
//static CPU_STK stack[PHYSICS_TASK_STACK_SIZE];


/*******************************************************************************
 *********************   LOCAL FUNCTION PROTOTYPES   ***************************
 ******************************************************************************/


/*******************************************************************************
 **************************   GLOBAL FUNCTIONS   *******************************
 ******************************************************************************/

/***************************************************************************//**
 * Initialize idle example.
 ******************************************************************************/
void physics_init(void)
{
//  RTOS_ERR err;
//
//  // Create Blink Task
//  OSTaskCreate(&tcb,
//               "speed setpoint task",
//               speed_setpoint_task,
//               DEF_NULL,
//               SPEED_SETPOINT_TASK_PRIO,
//               &stack[0],
//               (SPEED_SETPOINT_TASK_STACK_SIZE / 10u),
//               SPEED_SETPOINT_TASK_STACK_SIZE,
//               0u,
//               0u,
//               DEF_NULL,
//               (OS_OPT_TASK_STK_CLR),
//               &err);
//  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
//
//  speed_set_data.dec = 0;
//  speed_set_data.inc = 0;
//  speed_set_data.speed = 0;
//
//  OSMutexCreate(&SPEED_SET_MUTEX, "Speed Set Mutex", &err);
//  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
//
//  OSFlagCreate(&DATA_UPDATED_FLAG,"Data Updated Flag",0,&err);
//  /*   Check error code.                                  */
//  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}

/***************************************************************************//**
 * Blink task.
 ******************************************************************************/
//static void speed_setpoint_task(void *arg)
//{
//    PP_UNUSED_PARAM(arg);
//
//    RTOS_ERR err;
//    while (1)
//    {
//        OSSemPend(&BTN_PRESS_SEM,0,OS_OPT_PEND_BLOCKING,NULL,&err);
//        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
//        OSMutexPend(&SPEED_SET_MUTEX, 0, OS_OPT_PEND_BLOCKING ,NULL, &err);
//        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
//        CORE_CriticalDisableIrq();
//        OSIntEnter();
//        uint8_t btn0 = ReadFifoStr(&btn0_data);
//        uint8_t btn1 = ReadFifoStr(&btn1_data);
//        if(btn0 == BUTTON0_PRESS){
//            speed_set_data.inc++;
//            speed_set_data.speed +=5;
//        }
//        if(btn1 == BUTTON1_PRESS){
//            speed_set_data.dec++;
//            speed_set_data.speed -=5;
//        }
//        OSFlagPost(&DATA_UPDATED_FLAG, SPEED_FLAG_SET,OS_OPT_POST_FLAG_SET, &err);
//        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
//
//        OSIntExit();
//        CORE_CriticalEnableIrq();
//        OSMutexPost(&SPEED_SET_MUTEX, OS_OPT_POST_NONE, &err);
//        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
//    }
//}

bool MassStep(struct massposition_data* mass_pos, struct massvelocity_data mass_vel){
  if((!mass_pos)|(mass_pos->x > 127) | (mass_pos->y >127 )){
      return false;
  }
  mass_pos->x = mass_pos->x + mass_vel.x;
  mass_pos->y = mass_pos->y + mass_vel.y;
  return true;
}

bool ShieldStep(uint8_t* shield_pos, uint8_t* shield_vel, uint8_t shield_acc){
  if((!shield_pos)|(*shield_pos >127)|(*shield_pos < 3)){
      return false;
  }
   *shield_pos = *shield_pos + *shield_vel + 0.5*shield_acc;
   *shield_vel = *shield_vel + shield_acc;
   return true;

}

bool CollisionTest(uint8_t shield_pos,struct massposition_data mass_pos){
  if(mass_pos.y != 0){
  return false;
  }
  if(shield_pos == mass_pos.x){
      return true;
  }
  return false;
}

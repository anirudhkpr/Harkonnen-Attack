/***************************************************************************//**
 * @file
 * @brief Button functionality
 ******************************************************************************/


#ifndef BUTTONDATA_H
#define BUTTONDATA_H

#include "em_gpio.h"
#include "os.h"

struct button_data{
  uint8_t val;
  struct button_data* next;
};

//enum BUTTON_FLAG{NONE, BUTTON0_PRESS, BUTTON1_PRESS};

//***********************************************************************************
// global variables
//***********************************************************************************

void WriteFifoStr(struct button_data** btn_data, uint8_t value);
uint8_t ReadFifoStr(struct button_data** btn_data);
#endif  // BUTTON_H

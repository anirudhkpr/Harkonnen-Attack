/***************************************************************************//**
 * @file
 * @brief Button functionality
 ******************************************************************************/


#ifndef VEHICLEMONITOR_H
#define VEHICLEMONITOR_H

#include "em_gpio.h"
#include "capsense.h"

#define VEHICLEMONITOR_TASK_STACK_SIZE      960

#define VEHICLEMONITOR_TASK_PRIO            20

#define CAPSLIDER_DEFAULT 0x04

// CAPSENSE Channel 0 is
#define CSEN0_port gpioPortC
#define CSEN0_pin  0u
#define CSEN0_default false
// CAPSENSE Channel 1 is
#define CSEN1_port gpioPortC
#define CSEN1_pin  1u
#define CSEN1_default false
// CAPSENSE Channel 2 is
#define CSEN2_port gpioPortC
#define CSEN2_pin  2u
#define CSEN2_default false
// CAPSENSE Channel 3 is
#define CSEN3_port gpioPortC
#define CSEN3_pin  3u
#define CSEN3_default false
//***********************************************************************************
// global variables
//***********************************************************************************


extern OS_FLAG_GRP ALERT_EVENT_FLAG;
/***************************************************************************//**
 * Initialize button
 ******************************************************************************/
void vehicle_monitor_init(void);

#endif  // VEHICLEMONITOR_H

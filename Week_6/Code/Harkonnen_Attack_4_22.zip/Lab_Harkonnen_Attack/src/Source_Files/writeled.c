/***************************************************************************//**
 * @file
 * @brief Blink examples functions
 *****************************************************************************/
#include "os.h"
#include "VehicleMonitor.h"
#include "sliderinput.h"
#include "writeled.h"
#include "app.h"
/*******************************************************************************
 ***************************  LOCAL VARIABLES   ********************************
 ******************************************************************************/

static OS_TCB tcb;
static CPU_STK stack[WRITELED_TASK_STACK_SIZE];

/*******************************************************************************
 *********************   LOCAL FUNCTION PROTOTYPES   ***************************
 ******************************************************************************/

static void writeled_task(void *arg);

/*******************************************************************************
 **************************   GLOBAL FUNCTIONS   *******************************
 ******************************************************************************/

/***************************************************************************//**
 * Initialize writeled example.
 ******************************************************************************/
void writeled_init(void)
{
  RTOS_ERR err;

  // Create Blink Task
  OSTaskCreate(&tcb,
               "writeled task",
               writeled_task,
               DEF_NULL,
               WRITELED_TASK_PRIO,
               &stack[0],
               (WRITELED_TASK_STACK_SIZE / 10u),
               WRITELED_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}

/***************************************************************************//**
 * Blink task.
 ******************************************************************************/
static void writeled_task(void *arg)
{
    PP_UNUSED_PARAM(arg);

    RTOS_ERR err;
    while (1)
    {
        uint8_t flag = OSFlagPend(&ALERT_EVENT_FLAG,0x0F,0,OS_OPT_PEND_FLAG_SET_ANY + OS_OPT_PEND_FLAG_CONSUME + OS_OPT_PEND_BLOCKING,NULL,&err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
        if(flag == 0x09){
            GPIO_PinOutSet(LED0_port, LED0_pin);
            GPIO_PinOutClear(LED1_port, LED1_pin);
        }
        else if(flag == 0x06){
            GPIO_PinOutSet(LED1_port, LED1_pin);
            GPIO_PinOutClear(LED0_port, LED0_pin);
        }
        else if(flag == 0x03){
            GPIO_PinOutSet(LED0_port, LED0_pin);
            GPIO_PinOutSet(LED1_port, LED1_pin);
        }
        else if(flag == 0x0C){
            GPIO_PinOutClear(LED1_port, LED1_pin);
            GPIO_PinOutClear(LED0_port, LED0_pin);
        }
    }


}

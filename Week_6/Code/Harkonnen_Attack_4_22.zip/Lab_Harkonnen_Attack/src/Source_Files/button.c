/***************************************************************************//**
 * @file
 * @brief Button functionality
 ******************************************************************************/

#include "os.h"
#include "button.h"
#include "app.h"
#include "button_data.h"
/*******************************************************************************
 ***************************  LOCAL VARIABLES   ********************************
 ******************************************************************************/

/*******************************************************************************
 ***************************  GLOBAL VARIABLES   ********************************
 ******************************************************************************/
//bool btn0 = false;
//bool btn1 = false;
//static uint16_t btnpress;
//static OS_FLAG_GRP BUTTON_FLAG_GRP;
OS_SEM BTN_PRESS_SEM;
struct button_data* btn0_data;
struct button_data* btn1_data;
/*******************************************************************************
 *********************   LOCAL FUNCTION PROTOTYPES   ***************************
 ******************************************************************************/



/*******************************************************************************
 **************************   GLOBAL FUNCTIONS   *******************************
 ******************************************************************************/

/***************************************************************************//**
 * Initialize button example.
 ******************************************************************************/
void button_init(void)
{
  RTOS_ERR err;
  OSSemCreate(&BTN_PRESS_SEM,"Button Press Semaphore", 0,&err);
  /*   Check error code.                                  */
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

}

/***************************************************************************//**
 * @brief
 *   Interrupt handler to service pressing of buttons
 ******************************************************************************/
void GPIO_EVEN_IRQHandler(void)
{

  OSIntEnter();
  RTOS_ERR err;
//  OSFlagPost(&BUTTON_FLAG_GRP, BUTTON0_PRESS,OS_OPT_POST_FLAG_SET, &err);
//  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
  WriteFifoStr(&btn0_data, BUTTON0_PRESS);
  OSSemPost(&BTN_PRESS_SEM, OS_OPT_POST_ALL, &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
  GPIO->IFC = 0xFFFFFFFF;
  OSIntExit();
}

/***************************************************************************//**
 * @brief
 *   Interrupt handler to service pressing of buttons
 ******************************************************************************/
void GPIO_ODD_IRQHandler(void)
{
  OSIntEnter();
  RTOS_ERR err;
//  OSFlagPost(&BUTTON_FLAG_GRP, BUTTON1_PRESS,OS_OPT_POST_FLAG_SET, &err);
//  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
  WriteFifoStr(&btn1_data, BUTTON1_PRESS);
  OSSemPost(&BTN_PRESS_SEM, OS_OPT_POST_ALL, &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
  GPIO->IFC = 0xFFFFFFFF;
  OSIntExit();
}


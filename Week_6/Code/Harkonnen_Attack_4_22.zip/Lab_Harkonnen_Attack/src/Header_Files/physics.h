/***************************************************************************//**
 * @file
 * @brief PHYSICS functions
 ******************************************************************************/

#ifndef PHYSICS_H
#define PHYSICS_H

#include "gpio.h"
#include "sliderinput.h"
#include "button.h"

#define PHYSICS_TASK_STACK_SIZE      96

#define PHYSICS_TASK_PRIO            5

/***************************************************************************//**
 * Initialize PHYSICS example
 ******************************************************************************/
void physics_init(void);

struct massposition_data{
  uint8_t x;
  uint8_t y;
};

struct massvelocity_data{
  uint8_t x;
  uint8_t y;
};

extern struct massposition_data mass_pos;
//extern struct shield_data;
extern uint8_t shieldpos_data;

bool MassStep(struct massposition_data* mass_pos, struct massvelocity_data mass_vel);
bool ShieldStep(uint8_t* shield_pos, uint8_t* shield_vel, uint8_t shield_acc);
bool CollisionTest(uint8_t shield_pos,struct massposition_data mass_pos);
#endif  // PHYSICS_H

/***************************************************************************//**
 * @file
 * @brief SPEED_SETPOINT functions
 ******************************************************************************/

#ifndef SPEED_SETPOINT_H
#define SPEED_SETPOINT_H

#include "gpio.h"

#define SPEED_SETPOINT_TASK_STACK_SIZE      96

#define SPEED_SETPOINT_TASK_PRIO            5

#define SPEED_FLAG_SET                      01u
/***************************************************************************//**
 * Initialize SPEED_SETPOINT example
 ******************************************************************************/
void speed_setpoint_init(void);


struct speed_data{
  uint8_t speed;
  uint8_t inc;
  uint8_t dec;
};

extern struct speed_data speed_set_data;
extern OS_MUTEX SPEED_SET_MUTEX;
extern OS_FLAG_GRP DATA_UPDATED_FLAG;

#endif  // SPEED_SETPOINT_H
